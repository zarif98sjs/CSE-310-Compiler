g++ SymbolInfo.cpp ScopeTable.cpp SymbolTable.cpp 1705010.cpp -o main
