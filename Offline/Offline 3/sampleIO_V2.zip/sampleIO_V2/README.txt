Version 2.0 of sampleIO (Assignment 3)
----------
Changes:

1. Some inconsistencies of previous version updated.

(Line 60, 631 & 972 of log1.txt; line 408 of log2.txt)

2. Some more sample IO 
  - input 3 for more testing, input 4 for semantic errors, input 5 for syntax error recovery(bonus task)

3. Print scopetable when
	- exiting a scope
	- at the end of parsing
	
4. Depending on how you handle parameters in the parameter list for inserting in the new scope for a function, the scope ID may vary a bit. At this point we are not concerned with the scope ID, just the symboltable functionalities and elements inserted should work as expected.

4. Print error in both log.txt and error.txt

5. If there is any other conflict between this and the previous sampleIO , follow THIS version.

6. Try to follow the sampleIO as much as possible.

